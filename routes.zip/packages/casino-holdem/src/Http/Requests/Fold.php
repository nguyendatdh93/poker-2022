<?php

namespace Packages\CasinoHoldem\Http\Requests;

class Fold extends Action
{
    //
}
