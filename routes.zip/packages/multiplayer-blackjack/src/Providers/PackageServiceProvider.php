<?php

namespace Packages\MultiplayerBlackjack\Providers;

use App\Providers\PackageServiceProvider as DefaultPackageServiceProvider;

class PackageServiceProvider extends DefaultPackageServiceProvider
{
    protected $packageId = 'multiplayer-blackjack';
}
