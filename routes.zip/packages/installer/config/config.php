<?php

return [
    'version' => '1.0.0',
];