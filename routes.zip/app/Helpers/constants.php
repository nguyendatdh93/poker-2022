<?php

define('FP_CODE', 'PURCHASE_CODE');
define('FP_EMAIL', 'LICENSEE_EMAIL');
define('FP_HASH', 'SECURITY_HASH');
